Kevin Steele
This is my Pseudoshell project for CS 415 at University of Oregon. 
Compile using the Makefile, then run using ./pseudoshell.
To use filemode, run using ./pseudoshell -f <filename>.